-- 1. Criação da Tabela de Produtos
CREATE TABLE IF NOT EXISTS produtos (
    id SERIAL PRIMARY KEY,
    codigo_sku VARCHAR(50) UNIQUE NOT NULL,
    nome VARCHAR(150) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    material VARCHAR(100),
    medidas VARCHAR(100),
    preco NUMERIC(10,2) NOT NULL DEFAULT 0.00,
    imagem_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. Carga Inicial de Dados (Seed Data)
INSERT INTO produtos (codigo_sku, nome, categoria, material, medidas, preco, imagem_url) VALUES
('EL-101', 'Cabo Flexível 750V 2.5mm² Azul (Rolo 100m)', 'Elétrica', 'Cobre / PVC', '100 metros', 249.90, 'https://images.unsplash.com/photo-1544724569-5f546fd6f2b5?auto=format&fit=crop&w=400&q=80'),
('EL-102', 'Disjuntor Unipolar DIN 20A Curva C', 'Elétrica', 'Termoplástico / Metal', 'Padrão DIN', 18.90, 'https://images.unsplash.com/photo-1555680202-c86f0e12f086?auto=format&fit=crop&w=400&q=80'),
('HD-201', 'Tubo PVC Soldável 25mm 3/4" (6 Metros)', 'Hidráulica', 'PVC Rígido', '25mm x 6m', 38.50, 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=400&q=80'),
('HD-202', 'Joelho 90° PVC Soldável 25mm 3/4"', 'Hidráulica', 'PVC Rígido', '25mm', 2.45, 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&w=400&q=80'),
('IL-301', 'Painel LED Embutir 24W 6500K Quadrado', 'Iluminação', 'Alumínio / Acrílico', '30x30cm', 45.00, 'https://images.unsplash.com/photo-1565814636199-ae8133055c1c?auto=format&fit=crop&w=400&q=80'),
('IL-302', 'Lâmpada LED Bulbo 9W E27 Bivolt 3000K', 'Iluminação', 'Policarbonato', 'E27', 9.90, 'https://images.unsplash.com/photo-1550985616-10810253b84d?auto=format&fit=crop&w=400&q=80'),
('FR-401', 'Alicate Universal 8" Isolado 1000V', 'Ferramentas', 'Aço Cromo Vanádio', '8 polegadas', 64.90, 'https://images.unsplash.com/photo-1581147036324-c17ac41dfa6c?auto=format&fit=crop&w=400&q=80')
ON CONFLICT (codigo_sku) DO NOTHING;
